import { useState, useEffect, useRef } from "react";

// ── FONTS ──
const fontStyle = document.createElement('style');
fontStyle.textContent = `@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap');`;
document.head.appendChild(fontStyle);

// ── OWNER ──
const OWNER_EMAIL = "ramshidruziyev89@gmail.com";
const OWNER_PASSWORD = "admin123";

// ── STORAGE ──
const store = {
  get: (k, d = null) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};

// ── SAMPLE DATA ──
const INITIAL_TESTS = {
  listening: [
    { id: "l1", title: "IELTS Trainer 1, Test 1", category: "IELTS Trainer 1", type: "free", questions: 40, audioUrl: "", description: "Academic listening with four sections covering a range of social and academic topics." },
    { id: "l2", title: "IELTS Trainer 1, Test 2", category: "IELTS Trainer 1", type: "free", questions: 40, audioUrl: "", description: "Features conversations and monologues from native speakers in various contexts." },
    { id: "l3", title: "IELTS Trainer 1, Test 3", category: "IELTS Trainer 1", type: "free", questions: 40, audioUrl: "", description: "Extended monologue set in an everyday social context." },
    { id: "l4", title: "Test Plus 3, Test 1", category: "Test Plus 3", type: "premium", questions: 40, audioUrl: "", description: "Advanced listening test with complex academic discussions." },
    { id: "l5", title: "Test Plus 3, Test 2", category: "Test Plus 3", type: "premium", questions: 40, audioUrl: "", description: "Premium listening with university lecture content." },
    { id: "l6", title: "Test Plus 3, Test 3", category: "Test Plus 3", type: "premium", questions: 40, audioUrl: "", description: "Premium test featuring workplace and social conversations." },
  ],
  reading: [
    { id: "r1", title: "Frozen Food", category: "Academic", type: "free", questions: 14, description: "Explores the science and history behind frozen food preservation techniques." },
    { id: "r2", title: "Can the planet's coral reefs be saved?", category: "Academic", type: "free", questions: 14, description: "An examination of climate change impacts on coral reef ecosystems worldwide." },
    { id: "r3", title: "Robots and us", category: "Academic", type: "free", questions: 14, description: "Discusses the evolving relationship between humans and robotic technology." },
    { id: "r4", title: "Manhattan's Skyscrapers Race to the Top", category: "Academic", type: "premium", questions: 14, description: "The architectural and economic forces behind New York's iconic skyline." },
    { id: "r5", title: "Dyes and fabric dyeing", category: "Academic", type: "premium", questions: 14, description: "The chemistry and history of textile dyes from natural to synthetic." },
    { id: "r6", title: "The Brain That Changes Itself", category: "Academic", type: "premium", questions: 14, description: "Neuroplasticity and the brain's remarkable capacity for self-reorganization." },
  ],
  writing: [
    { id: "w1", title: "Writing Task 1 — Bar Chart", category: "Task 1", type: "free", description: "Describe and compare data shown in a bar chart about energy consumption." },
    { id: "w2", title: "Writing Task 1 — Line Graph", category: "Task 1", type: "free", description: "Summarise trends shown in a line graph about population growth." },
    { id: "w3", title: "Writing Task 2 — Opinion Essay", category: "Task 2", type: "free", description: "Discuss the advantages and disadvantages of remote working." },
    { id: "w4", title: "Writing Task 1 — Process Diagram", category: "Task 1", type: "premium", description: "Describe the stages of water recycling shown in a process diagram." },
    { id: "w5", title: "Writing Task 2 — Discussion Essay", category: "Task 2", type: "premium", description: "Some believe technology makes life easier. Discuss both views." },
  ],
  speaking: [
    { id: "sp1", title: "Daily Life & Routines", category: "Part 1", type: "free", description: "Common Part 1 questions about hobbies, home, work, and daily habits." },
    { id: "sp2", title: "Describe a Memorable Journey", category: "Part 2", type: "free", description: "Part 2 cue card — describe a journey that made a strong impression on you." },
    { id: "sp3", title: "Technology & Society", category: "Part 3", type: "free", description: "In-depth Part 3 discussion on technology's role in modern life." },
    { id: "sp4", title: "Education & Learning", category: "Part 1", type: "premium", description: "Premium set of Part 1 questions about education, study habits, and schools." },
    { id: "sp5", title: "Describe a Person You Admire", category: "Part 2", type: "premium", description: "Premium Part 2 — describe an influential person in your life." },
  ]
};

const FULL_MOCKS = [
  { id: "fm1", title: "Full Mock Test 1", type: "free", description: "Complete IELTS simulation — Listening, Reading, Writing, and Speaking under timed conditions.", duration: "2h 45m", sections: ["Listening","Reading","Writing","Speaking"] },
  { id: "fm2", title: "Full Mock Test 2", type: "premium", description: "Advanced full mock with harder passages and complex listening audio.", duration: "2h 45m", sections: ["Listening","Reading","Writing","Speaking"] },
  { id: "fm3", title: "Full Mock Test 3", type: "premium", description: "Band 7+ targeted full mock test with comprehensive answer explanations.", duration: "2h 45m", sections: ["Listening","Reading","Writing","Speaking"] },
];

function initStorage() {
  if (!store.get('rm2_init')) {
    store.set('rm2_users', []);
    store.set('rm2_tests', INITIAL_TESTS);
    store.set('rm2_mocks', FULL_MOCKS);
    store.set('rm2_requests', []);
    store.set('rm2_submissions', []);
    store.set('rm2_init', true);
  }
}

// ── DOWNLOAD (owner only) ──
function downloadSection(sectionName, tests) {
  let txt = `RUZIYEVMOCK — ${sectionName.toUpperCase()} TESTS\nOwner: ${OWNER_EMAIL}\nExported: ${new Date().toLocaleString()}\n${'='.repeat(60)}\n\n`;
  tests.forEach((t, i) => {
    txt += `${i+1}. ${t.title}\n   Category: ${t.category}\n   Type: ${t.type.toUpperCase()}\n   ${t.description}\n\n`;
  });
  const blob = new Blob([txt], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `ruziyevmock_${sectionName}_tests.txt`;
  a.click();
}

// ── CSS ──
const CSS = `
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  :root{
    --bg:#f0f4f8;
    --surface:#ffffff;
    --border:#e2e8f0;
    --accent:#0ea5e9;
    --accent-dark:#0284c7;
    --green:#10b981;
    --green-dark:#059669;
    --purple:#8b5cf6;
    --orange:#f59e0b;
    --red:#ef4444;
    --text:#0f172a;
    --text2:#475569;
    --muted:#94a3b8;
    --card:#ffffff;
    --premium-bg:#faf5ff;
    --premium-border:#e9d5ff;
    --owner:#7c3aed;
  }
  body{background:var(--bg);color:var(--text);font-family:'Outfit',sans-serif;font-size:15px;line-height:1.6;}
  input,textarea,select,button{font-family:inherit;}
  ::-webkit-scrollbar{width:5px;}
  ::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:4px;}
  .app{min-height:100vh;display:flex;flex-direction:column;}

  /* ── NAV ── */
  .nav{
    background:#fff;border-bottom:1px solid var(--border);
    padding:0 1.5rem;height:60px;
    display:flex;align-items:center;justify-content:space-between;
    position:sticky;top:0;z-index:200;
    box-shadow:0 1px 12px rgba(0,0,0,0.06);
  }
  .nav-logo{display:flex;align-items:center;gap:0.5rem;cursor:pointer;}
  .nav-logo-icon{width:36px;height:36px;background:linear-gradient(135deg,var(--accent),var(--green));border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;}
  .nav-logo-text{font-weight:800;font-size:1.15rem;color:var(--text);letter-spacing:-0.03em;}
  .nav-logo-text span{color:var(--accent);}
  .nav-right{display:flex;align-items:center;gap:0.6rem;}
  .nav-greeting{font-size:0.82rem;color:var(--text2);font-weight:500;}
  .nav-greeting strong{color:var(--accent);}
  .owner-pill{background:linear-gradient(135deg,var(--owner),#a855f7);color:#fff;font-size:0.68rem;font-weight:700;padding:0.2rem 0.6rem;border-radius:100px;letter-spacing:0.05em;}

  /* ── BUTTONS ── */
  .btn{padding:0.5rem 1.1rem;border-radius:10px;border:none;cursor:pointer;font-size:0.83rem;font-weight:600;transition:all 0.18s;display:inline-flex;align-items:center;gap:0.35rem;}
  .btn-xs{padding:0.28rem 0.7rem;font-size:0.75rem;border-radius:8px;}
  .btn-sm{padding:0.38rem 0.85rem;font-size:0.8rem;}
  .btn-lg{padding:0.75rem 1.8rem;font-size:0.95rem;border-radius:12px;}
  .btn-primary{background:var(--accent);color:#fff;box-shadow:0 2px 8px rgba(14,165,233,0.3);}
  .btn-primary:hover{background:var(--accent-dark);transform:translateY(-1px);box-shadow:0 4px 12px rgba(14,165,233,0.4);}
  .btn-green{background:var(--green);color:#fff;box-shadow:0 2px 8px rgba(16,185,129,0.3);}
  .btn-green:hover{background:var(--green-dark);transform:translateY(-1px);}
  .btn-purple{background:var(--purple);color:#fff;}
  .btn-purple:hover{background:#7c3aed;transform:translateY(-1px);}
  .btn-ghost{background:var(--bg);color:var(--text2);border:1px solid var(--border);}
  .btn-ghost:hover{background:var(--border);color:var(--text);}
  .btn-danger{background:var(--red);color:#fff;}
  .btn-danger:hover{background:#dc2626;}
  .btn-owner{background:linear-gradient(135deg,var(--owner),#a855f7);color:#fff;}
  .btn-owner:hover{opacity:0.9;transform:translateY(-1px);}
  .btn:disabled{opacity:0.4;cursor:not-allowed;transform:none!important;}

  /* ── AUTH ── */
  .auth-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,#0ea5e9 0%,#0f172a 100%);padding:1.5rem;position:relative;overflow:hidden;}
  .auth-wrap::before{content:'';position:absolute;top:-100px;right:-100px;width:400px;height:400px;border-radius:50%;background:rgba(255,255,255,0.04);pointer-events:none;}
  .auth-wrap::after{content:'';position:absolute;bottom:-80px;left:-80px;width:300px;height:300px;border-radius:50%;background:rgba(16,185,129,0.08);pointer-events:none;}
  .auth-box{background:#fff;border-radius:24px;padding:2.5rem;width:100%;max-width:420px;box-shadow:0 40px 80px rgba(0,0,0,0.25);position:relative;z-index:1;}
  .auth-header{text-align:center;margin-bottom:1.8rem;}
  .auth-icon{width:56px;height:56px;background:linear-gradient(135deg,var(--accent),var(--green));border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;margin:0 auto 1rem;}
  .auth-title{font-family:'Instrument Serif',serif;font-size:1.7rem;color:var(--text);font-weight:400;}
  .auth-sub{color:var(--muted);font-size:0.85rem;margin-top:0.3rem;}
  .auth-tabs{display:grid;grid-template-columns:1fr 1fr;gap:0;background:var(--bg);border-radius:12px;padding:4px;margin-bottom:1.8rem;}
  .auth-tab{padding:0.55rem;border:none;background:transparent;border-radius:9px;cursor:pointer;font-weight:600;font-size:0.85rem;color:var(--muted);transition:all 0.2s;}
  .auth-tab.active{background:#fff;color:var(--accent);box-shadow:0 2px 8px rgba(0,0,0,0.08);}
  .field{margin-bottom:1rem;}
  .field label{display:block;font-size:0.78rem;font-weight:700;color:var(--text2);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.05em;}
  .field input{width:100%;padding:0.7rem 1rem;border:1.5px solid var(--border);border-radius:10px;font-size:0.9rem;color:var(--text);background:#fafbfc;outline:none;transition:border-color 0.2s,background 0.2s;}
  .field input:focus{border-color:var(--accent);background:#fff;}
  .auth-submit{width:100%;padding:0.85rem;background:linear-gradient(135deg,var(--accent),var(--accent-dark));color:#fff;border:none;border-radius:12px;font-weight:700;font-size:0.95rem;cursor:pointer;margin-top:0.5rem;transition:all 0.2s;box-shadow:0 4px 12px rgba(14,165,233,0.35);}
  .auth-submit:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(14,165,233,0.45);}
  .err-box{color:#dc2626;font-size:0.82rem;padding:0.55rem 0.9rem;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;margin-top:0.5rem;}
  .ok-box{color:#059669;font-size:0.82rem;padding:0.55rem 0.9rem;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;margin-top:0.5rem;}

  /* ── MAIN ── */
  .main{flex:1;padding:1.5rem;max-width:900px;margin:0 auto;width:100%;}

  /* ── HOME HERO ── */
  .home-hero{
    background:linear-gradient(135deg,var(--accent) 0%,#0284c7 50%,#0f172a 100%);
    border-radius:24px;padding:2rem 1.8rem;margin-bottom:1.5rem;
    position:relative;overflow:hidden;
  }
  .home-hero::after{content:'🎓';position:absolute;right:1.5rem;bottom:-0.5rem;font-size:5rem;opacity:0.1;}
  .hero-greeting{color:rgba(255,255,255,0.75);font-size:0.85rem;font-weight:500;margin-bottom:0.3rem;}
  .hero-title{font-family:'Instrument Serif',serif;font-size:1.8rem;color:#fff;font-weight:400;line-height:1.2;margin-bottom:0.5rem;}
  .hero-title span{color:#7dd3fc;}
  .hero-sub{color:rgba(255,255,255,0.65);font-size:0.85rem;max-width:380px;}
  .hero-stats{display:flex;gap:1.5rem;margin-top:1.5rem;flex-wrap:wrap;}
  .hero-stat{text-align:center;}
  .hero-stat-num{font-weight:800;font-size:1.3rem;color:#fff;}
  .hero-stat-label{font-size:0.72rem;color:rgba(255,255,255,0.6);text-transform:uppercase;letter-spacing:0.06em;}

  /* ── SECTION CARDS (home) ── */
  .section-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:1rem;margin-bottom:1.5rem;}
  .section-card{
    background:var(--card);border-radius:18px;padding:1.4rem;
    border:1.5px solid var(--border);cursor:pointer;
    transition:all 0.22s;position:relative;overflow:hidden;
  }
  .section-card:hover{transform:translateY(-3px);box-shadow:0 10px 30px rgba(0,0,0,0.1);border-color:var(--card-accent,var(--accent));}
  .section-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--card-accent,var(--accent));}
  .sc-icon{width:48px;height:48px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin-bottom:1rem;background:var(--card-accent-bg,#e0f2fe);}
  .sc-title{font-weight:800;font-size:1rem;color:var(--text);margin-bottom:0.2rem;}
  .sc-count{font-size:0.78rem;color:var(--muted);font-weight:500;}
  .sc-arrow{position:absolute;right:1.2rem;top:50%;transform:translateY(-50%);color:var(--muted);font-size:1.1rem;}

  /* ── FULL MOCK (home) ── */
  .full-mock-banner{
    background:linear-gradient(135deg,#0f172a,#1e3a5f);
    border-radius:20px;padding:1.5rem 1.8rem;cursor:pointer;
    transition:all 0.22s;border:1.5px solid rgba(14,165,233,0.2);
    display:flex;align-items:center;gap:1.2rem;
  }
  .full-mock-banner:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(0,0,0,0.2);}
  .fm-icon{font-size:2.2rem;flex-shrink:0;}
  .fm-title{font-family:'Instrument Serif',serif;font-size:1.3rem;color:#fff;font-weight:400;}
  .fm-sub{font-size:0.82rem;color:rgba(255,255,255,0.55);margin-top:0.2rem;}
  .fm-arrow{margin-left:auto;color:var(--accent);font-size:1.4rem;flex-shrink:0;}

  /* ── PREMIUM BANNER ── */
  .premium-bar{background:linear-gradient(135deg,#fef3c7,#fde68a);border:1.5px solid #fcd34d;border-radius:16px;padding:1rem 1.2rem;display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap;}
  .premium-bar-text{flex:1;}
  .premium-bar-title{font-weight:700;color:#92400e;font-size:0.88rem;}
  .premium-bar-sub{font-size:0.78rem;color:#b45309;margin-top:0.1rem;}

  /* ── PAGE HEADER ── */
  .page-header-bar{
    border-radius:18px;padding:1.4rem 1.6rem;margin-bottom:1.5rem;
    display:flex;align-items:center;gap:1rem;
  }
  .phb-icon{font-size:2rem;flex-shrink:0;}
  .phb-title{font-family:'Instrument Serif',serif;font-size:1.5rem;font-weight:400;color:#fff;}
  .phb-sub{font-size:0.82rem;color:rgba(255,255,255,0.65);margin-top:0.2rem;}
  .back-btn{display:inline-flex;align-items:center;gap:0.4rem;color:var(--text2);font-weight:600;font-size:0.85rem;cursor:pointer;margin-bottom:1.2rem;padding:0.4rem 0;transition:color 0.15s;}
  .back-btn:hover{color:var(--accent);}

  /* ── FILTER BAR ── */
  .filter-box{background:#fff;border:1.5px solid var(--border);border-radius:16px;padding:1rem 1.2rem;margin-bottom:1.2rem;}
  .filter-label{font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--muted);margin-bottom:0.7rem;}
  .filter-options{display:flex;flex-direction:column;gap:0.4rem;}
  .filter-opt{display:flex;align-items:center;justify-content:space-between;padding:0.55rem 0.85rem;border-radius:10px;cursor:pointer;border:1.5px solid transparent;transition:all 0.15s;font-size:0.85rem;font-weight:500;color:var(--text2);}
  .filter-opt:hover{background:var(--bg);}
  .filter-opt.active{background:var(--accent);color:#fff;border-color:var(--accent);}
  .filter-opt.active .filter-count{background:rgba(255,255,255,0.25);color:#fff;}
  .filter-count{background:var(--bg);color:var(--muted);font-size:0.72rem;font-weight:700;padding:0.1rem 0.5rem;border-radius:100px;}
  .filter-opt-inner{display:flex;align-items:center;gap:0.5rem;}

  /* ── TEST CARDS ── */
  .tests-list{display:flex;flex-direction:column;gap:0.75rem;}
  .test-item{background:#fff;border-radius:14px;padding:1.1rem 1.2rem;border:1.5px solid var(--border);transition:all 0.18s;}
  .test-item:hover{box-shadow:0 4px 16px rgba(0,0,0,0.08);border-color:var(--accent);}
  .test-item.premium-item{background:var(--premium-bg);border-color:var(--premium-border);}
  .test-item-top{display:flex;align-items:flex-start;gap:0.8rem;margin-bottom:0.8rem;}
  .test-item-badges{display:flex;gap:0.4rem;flex-wrap:wrap;margin-bottom:0.4rem;}
  .badge{display:inline-flex;align-items:center;gap:0.25rem;padding:0.18rem 0.6rem;border-radius:100px;font-size:0.7rem;font-weight:700;letter-spacing:0.03em;}
  .badge-free{background:#d1fae5;color:#065f46;}
  .badge-premium{background:#ede9fe;color:#5b21b6;}
  .badge-cat{background:var(--bg);color:var(--text2);}
  .badge-new{background:#fee2e2;color:#991b1b;}
  .test-item-title{font-weight:700;font-size:0.92rem;color:var(--text);line-height:1.4;}
  .test-item-desc{font-size:0.8rem;color:var(--muted);margin-top:0.2rem;line-height:1.5;}
  .test-item-meta{font-size:0.75rem;color:var(--muted);display:flex;align-items:center;gap:0.4rem;margin-top:0.3rem;}
  .test-item-actions{display:flex;align-items:center;gap:0.5rem;margin-top:0.8rem;}

  /* ── SECTION HEADERS (within list) ── */
  .list-section-header{display:flex;align-items:center;gap:0.6rem;margin:1.2rem 0 0.8rem;padding-bottom:0.6rem;border-bottom:1.5px solid var(--border);}
  .lsh-icon{font-size:1rem;}
  .lsh-title{font-weight:800;font-size:0.92rem;color:var(--text);}
  .lsh-count{font-size:0.75rem;color:var(--muted);font-weight:600;}
  .premium-section-header{display:flex;align-items:center;gap:0.5rem;margin:1.5rem 0 0.8rem;padding:0.7rem 1rem;background:#ede9fe;border-radius:12px;}
  .psh-title{font-weight:700;color:#5b21b6;font-size:0.88rem;}
  .psh-count{margin-left:auto;font-size:0.75rem;color:#7c3aed;font-weight:700;}

  /* ── FULL MOCK PAGE ── */
  .mock-grid{display:flex;flex-direction:column;gap:1rem;}
  .mock-card{background:#fff;border-radius:16px;padding:1.4rem;border:1.5px solid var(--border);transition:all 0.2s;}
  .mock-card.premium-item{background:var(--premium-bg);border-color:var(--premium-border);}
  .mock-card:hover{box-shadow:0 6px 20px rgba(0,0,0,0.1);border-color:var(--accent);}
  .mock-card-header{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:0.8rem;}
  .mock-card-title{font-weight:800;font-size:1rem;color:var(--text);}
  .mock-card-desc{font-size:0.82rem;color:var(--muted);line-height:1.55;margin-bottom:1rem;}
  .mock-sections-row{display:flex;gap:0.4rem;flex-wrap:wrap;margin-bottom:1rem;}
  .mock-section-tag{padding:0.2rem 0.6rem;background:var(--bg);border-radius:6px;font-size:0.72rem;font-weight:600;color:var(--text2);}
  .mock-duration{font-size:0.75rem;color:var(--muted);display:flex;align-items:center;gap:0.3rem;}

  /* ── TEST TAKING ── */
  .test-header-bar{border-radius:18px;padding:1.5rem;margin-bottom:1.5rem;}
  .section-nav{display:flex;background:#fff;border:1.5px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:1.5rem;}
  .section-nav-btn{flex:1;padding:0.8rem 0.5rem;border:none;background:transparent;cursor:pointer;font-size:0.8rem;font-weight:600;color:var(--muted);border-bottom:3px solid transparent;transition:all 0.15s;}
  .section-nav-btn.active{color:var(--accent);border-bottom-color:var(--accent);background:#f0f9ff;}
  .test-body{background:#fff;border-radius:18px;border:1.5px solid var(--border);overflow:hidden;}
  .test-body-inner{padding:1.5rem;}

  /* QUESTIONS */
  .q-block{margin-bottom:1.5rem;padding:1.2rem;background:var(--bg);border-radius:12px;border:1.5px solid var(--border);}
  .q-block.correct{border-color:var(--green);background:#f0fdf4;}
  .q-block.incorrect{border-color:var(--red);background:#fef2f2;}
  .q-num{font-size:0.68rem;font-weight:800;text-transform:uppercase;letter-spacing:0.1em;color:var(--accent);margin-bottom:0.4rem;}
  .q-text{font-weight:600;color:var(--text);margin-bottom:0.8rem;line-height:1.5;font-size:0.9rem;}
  .opt{display:flex;align-items:center;gap:0.6rem;padding:0.55rem 0.9rem;border-radius:9px;cursor:pointer;transition:all 0.12s;border:1.5px solid transparent;margin-bottom:0.4rem;font-size:0.88rem;}
  .opt:hover{background:#fff;border-color:var(--border);}
  .opt.selected{background:var(--accent);color:#fff;border-color:var(--accent);}
  .opt.correct-ans{background:#d1fae5;border-color:var(--green);color:#065f46;}
  .opt.wrong-ans{background:#fee2e2;border-color:var(--red);color:#991b1b;}
  .opt-dot{width:15px;height:15px;border-radius:50%;border:2px solid currentColor;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
  .opt.selected .opt-dot::after,.opt.correct-ans .opt-dot::after{content:'';width:7px;height:7px;border-radius:50%;background:currentColor;}

  /* PASSAGE */
  .passage-box{background:var(--bg);border:1.5px solid var(--border);border-radius:12px;padding:1.3rem;font-size:0.87rem;line-height:1.85;color:var(--text);margin-bottom:1.5rem;max-height:360px;overflow-y:auto;white-space:pre-wrap;}

  /* WRITING */
  .writing-prompt-box{background:#eff6ff;border-left:4px solid var(--accent);padding:1rem 1.2rem;border-radius:0 10px 10px 0;font-size:0.87rem;line-height:1.65;color:var(--text);margin-bottom:1rem;white-space:pre-wrap;}
  .writing-ta{width:100%;border:1.5px solid var(--border);border-radius:12px;padding:1rem;font-size:0.88rem;line-height:1.7;color:var(--text);background:var(--bg);resize:vertical;outline:none;transition:border-color 0.2s;}
  .writing-ta:focus{border-color:var(--accent);background:#fff;}
  .wc{text-align:right;font-size:0.75rem;margin-top:0.35rem;font-weight:600;}

  /* SPEAKING */
  .sp-card{background:var(--bg);border:1.5px solid var(--border);border-radius:12px;padding:1.2rem;margin-bottom:0.9rem;}
  .sp-q{font-weight:600;color:var(--text);font-size:0.9rem;line-height:1.5;}
  .cue-box{background:linear-gradient(135deg,var(--accent),var(--accent-dark));color:#fff;border-radius:14px;padding:1.5rem;margin-bottom:1.2rem;white-space:pre-wrap;line-height:1.7;font-size:0.88rem;}
  .timer-big{font-family:'Instrument Serif',serif;font-size:3.5rem;font-weight:400;color:var(--accent);text-align:center;margin:0.8rem 0;}
  .timer-big.warn{color:var(--red);}
  .mic-btn{width:60px;height:60px;border-radius:50%;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 0.7rem;transition:all 0.2s;}
  .mic-btn.idle{background:var(--accent);color:#fff;box-shadow:0 4px 14px rgba(14,165,233,0.4);}
  .mic-btn.rec{background:var(--red);color:#fff;animation:mpulse 1.5s infinite;box-shadow:0 4px 14px rgba(239,68,68,0.5);}
  @keyframes mpulse{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}

  /* RESULTS */
  .result-hero{background:linear-gradient(135deg,var(--accent),var(--accent-dark));border-radius:20px;padding:1.8rem;margin-bottom:1.5rem;display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap;}
  .result-band{font-family:'Instrument Serif',serif;font-size:4rem;color:#fff;font-weight:400;line-height:1;}
  .result-band small{font-size:1.2rem;opacity:0.6;}
  .result-info h2{font-family:'Instrument Serif',serif;font-size:1.3rem;color:#fff;font-weight:400;}
  .result-info p{color:rgba(255,255,255,0.7);font-size:0.83rem;margin-top:0.3rem;}

  /* ADMIN */
  .admin-layout{display:grid;grid-template-columns:200px 1fr;gap:1.2rem;}
  .admin-sidebar{background:linear-gradient(170deg,#0f172a,#1e3a5f);border-radius:18px;padding:1.2rem;}
  .admin-sidebar-title{color:rgba(255,255,255,0.4);font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.8rem;}
  .a-nav-item{display:flex;align-items:center;gap:0.6rem;padding:0.6rem 0.8rem;border-radius:10px;color:rgba(255,255,255,0.6);cursor:pointer;font-size:0.83rem;font-weight:600;margin-bottom:0.25rem;transition:all 0.15s;}
  .a-nav-item:hover{background:rgba(255,255,255,0.08);color:#fff;}
  .a-nav-item.active{background:rgba(14,165,233,0.2);color:#7dd3fc;}
  .admin-panel{background:#fff;border-radius:18px;border:1.5px solid var(--border);padding:1.5rem;}
  .admin-panel-title{font-family:'Instrument Serif',serif;font-size:1.3rem;color:var(--text);margin-bottom:1.2rem;font-weight:400;}

  /* TABLE */
  .tbl-wrap{overflow-x:auto;}
  table{width:100%;border-collapse:collapse;font-size:0.82rem;}
  th{text-align:left;padding:0.6rem 0.8rem;background:var(--bg);color:var(--muted);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;border-bottom:1.5px solid var(--border);}
  td{padding:0.75rem 0.8rem;border-bottom:1px solid var(--border);color:var(--text);vertical-align:middle;}
  tr:last-child td{border-bottom:none;}
  tr:hover td{background:#fafbfc;}

  /* STATS */
  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:0.75rem;margin-bottom:1.2rem;}
  .stat-box{background:var(--bg);border-radius:12px;padding:1rem;text-align:center;border:1.5px solid var(--border);}
  .stat-n{font-family:'Instrument Serif',serif;font-size:1.9rem;color:var(--accent);}
  .stat-l{font-size:0.7rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:0.06em;margin-top:0.1rem;}

  /* MODAL */
  .modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:500;display:flex;align-items:center;justify-content:center;padding:1rem;}
  .modal-box{background:#fff;border-radius:20px;padding:2rem;width:100%;max-width:520px;max-height:88vh;overflow-y:auto;box-shadow:0 30px 70px rgba(0,0,0,0.25);}
  .modal-title{font-family:'Instrument Serif',serif;font-size:1.3rem;color:var(--text);margin-bottom:1.2rem;font-weight:400;}
  .modal-footer{display:flex;gap:0.6rem;justify-content:flex-end;margin-top:1.2rem;}

  /* CHIP */
  .chip{display:inline-block;padding:0.18rem 0.6rem;border-radius:100px;font-size:0.7rem;font-weight:700;letter-spacing:0.03em;}
  .chip-free{background:#d1fae5;color:#065f46;}
  .chip-premium{background:#ede9fe;color:#5b21b6;}
  .chip-pending{background:#fef3c7;color:#92400e;}
  .chip-approved{background:#d1fae5;color:#065f46;}
  .chip-rejected{background:#fee2e2;color:#991b1b;}

  /* UPLOAD */
  .upload-zone{border:2px dashed var(--border);border-radius:12px;padding:1.8rem;text-align:center;cursor:pointer;transition:all 0.2s;background:var(--bg);}
  .upload-zone:hover{border-color:var(--accent);background:#f0f9ff;}
  .upload-zone.has-file{border-color:var(--green);background:#f0fdf4;}

  /* MISC */
  .divider{height:1px;background:var(--border);margin:1.2rem 0;}
  .flex{display:flex;}
  .items-center{align-items:center;}
  .justify-between{justify-content:space-between;}
  .gap-1{gap:0.4rem;}
  .gap-2{gap:0.8rem;}
  .flex-wrap{flex-wrap:wrap;}
  .empty-state{text-align:center;padding:2.5rem;color:var(--muted);}
  .empty-icon{font-size:2.5rem;margin-bottom:0.6rem;}

  /* OWNER DOWNLOAD STRIP */
  .owner-downloads{background:linear-gradient(135deg,#f5f3ff,#ede9fe);border:1.5px solid #ddd6fe;border-radius:16px;padding:1rem 1.2rem;margin-bottom:1.2rem;}
  .owner-dl-title{font-size:0.78rem;font-weight:800;color:var(--owner);text-transform:uppercase;letter-spacing:0.07em;margin-bottom:0.7rem;display:flex;align-items:center;gap:0.4rem;}
  .owner-dl-row{display:flex;gap:0.5rem;flex-wrap:wrap;}

  @media(max-width:640px){
    .admin-layout{grid-template-columns:1fr;}
    .admin-sidebar{display:flex;flex-wrap:wrap;gap:0.4rem;}
    .admin-sidebar-title{display:none;}
    .section-grid{grid-template-columns:1fr;}
    .nav{padding:0 1rem;}
    .main{padding:1rem;}
  }
`;
const styleEl = document.createElement('style');
styleEl.textContent = CSS;
document.head.appendChild(styleEl);

// ── NAV ──
function Navbar({ user, onLogout, onNav }) {
  const isOwner = user?.role === 'admin';
  return (
    <nav className="nav">
      <div className="nav-logo" onClick={() => onNav('home')}>
        <div className="nav-logo-icon">🎓</div>
        <div className="nav-logo-text">ruziyev<span>mock</span></div>
      </div>
      <div className="nav-right">
        {user && <span className="nav-greeting">Hello, <strong>{user.name.split(' ')[0]}</strong></span>}
        {isOwner && <span className="owner-pill">👑 OWNER</span>}
        {isOwner && <button className="btn btn-owner btn-xs" onClick={() => onNav('admin')}>⚙ Panel</button>}
        {user && <button className="btn btn-ghost btn-xs" onClick={() => onNav('profile')}>My Tests</button>}
        {user
          ? <button className="btn btn-ghost btn-xs" onClick={onLogout}>Log out</button>
          : <button className="btn btn-primary btn-xs" onClick={() => onNav('auth')}>Sign In</button>}
      </div>
    </nav>
  );
}

// ── AUTH ──
function AuthPage({ onLogin }) {
  const [tab, setTab] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  function login() {
    setErr('');
    if (form.email.trim().toLowerCase() === OWNER_EMAIL.toLowerCase() && form.password === OWNER_PASSWORD) {
      onLogin({ id: 'owner', email: OWNER_EMAIL, name: 'Ramshid', role: 'admin', premium: true }); return;
    }
    const users = store.get('rm2_users', []);
    const u = users.find(u => u.email === form.email.trim().toLowerCase() && u.password === form.password);
    if (!u) { setErr('Email yoki parol noto\'g\'ri.'); return; }
    onLogin({ ...u, role: 'user' });
  }

  function register() {
    setErr('');
    if (!form.name.trim() || !form.email.trim() || !form.password) { setErr('Barcha maydonlarni to\'ldiring.'); return; }
    if (form.password !== form.confirm) { setErr('Parollar mos kelmadi.'); return; }
    if (form.password.length < 6) { setErr('Parol kamida 6 ta belgidan iborat bo\'lishi kerak.'); return; }
    if (form.email.trim().toLowerCase() === OWNER_EMAIL.toLowerCase()) { setErr('Bu email ro\'yxatdan o\'tkazib bo\'lmaydi.'); return; }
    const users = store.get('rm2_users', []);
    if (users.find(u => u.email === form.email.trim().toLowerCase())) { setErr('Bu email allaqachon ro\'yxatdan o\'tgan.'); return; }
    const nu = { id: Date.now().toString(), name: form.name.trim(), email: form.email.trim().toLowerCase(), password: form.password, role: 'user', premium: false, joined: new Date().toISOString() };
    store.set('rm2_users', [...users, nu]);
    setOk('Hisob yaratildi! Endi tizimga kiring.');
    setTab('login');
    setForm(f => ({ ...f, password: '', confirm: '' }));
  }

  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <div className="auth-header">
          <div className="auth-icon">🎓</div>
          <div className="auth-title">ruziyevmock</div>
          <div className="auth-sub">IELTS Mock Test Platform</div>
        </div>
        <div className="auth-tabs">
          <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => { setTab('login'); setErr(''); setOk(''); }}>Kirish</button>
          <button className={`auth-tab ${tab === 'register' ? 'active' : ''}`} onClick={() => { setTab('register'); setErr(''); setOk(''); }}>Ro'yxat</button>
        </div>
        {tab === 'login' ? (
          <>
            <div className="field"><label>Email</label><input type="email" placeholder="email@example.com" value={form.email} onChange={e => set('email', e.target.value)} onKeyDown={e => e.key === 'Enter' && login()} /></div>
            <div className="field"><label>Parol</label><input type="password" placeholder="••••••••" value={form.password} onChange={e => set('password', e.target.value)} onKeyDown={e => e.key === 'Enter' && login()} /></div>
            {err && <div className="err-box">{err}</div>}
            {ok && <div className="ok-box">{ok}</div>}
            <button className="auth-submit" onClick={login}>Kirish →</button>
          </>
        ) : (
          <>
            <div className="field"><label>To'liq ism</label><input placeholder="Ismingiz" value={form.name} onChange={e => set('name', e.target.value)} /></div>
            <div className="field"><label>Email</label><input type="email" placeholder="email@example.com" value={form.email} onChange={e => set('email', e.target.value)} /></div>
            <div className="field"><label>Parol</label><input type="password" placeholder="Kamida 6 ta belgi" value={form.password} onChange={e => set('password', e.target.value)} /></div>
            <div className="field"><label>Parolni tasdiqlang</label><input type="password" placeholder="Parolni takrorlang" value={form.confirm} onChange={e => set('confirm', e.target.value)} onKeyDown={e => e.key === 'Enter' && register()} /></div>
            {err && <div className="err-box">{err}</div>}
            <button className="auth-submit" onClick={register}>Ro'yxatdan o'tish →</button>
          </>
        )}
      </div>
    </div>
  );
}

// ── HOME ──
function HomePage({ user, onNav }) {
  const isOwner = user?.role === 'admin';
  const tests = store.get('rm2_tests', INITIAL_TESTS);
  const mocks = store.get('rm2_mocks', FULL_MOCKS);
  const sections = [
    { key: 'listening', icon: '🎧', label: 'Listening', color: '#10b981', bg: '#d1fae5', desc: 'Audio testlar' },
    { key: 'reading', icon: '📖', label: 'Reading', color: '#3b82f6', bg: '#dbeafe', desc: 'O\'qish testlari' },
    { key: 'writing', icon: '✍️', label: 'Writing', color: '#f59e0b', bg: '#fef3c7', desc: 'Yozish mashqlari' },
    { key: 'speaking', icon: '🎤', label: 'Speaking', color: '#ef4444', bg: '#fee2e2', desc: 'Gapirish mashqlari' },
  ];

  return (
    <div>
      <div className="home-hero">
        <div className="hero-greeting">{user ? `Xush kelibsiz, ${user.name.split(' ')[0]}!` : 'IELTS Mock Test Platformasi'}</div>
        <div className="hero-title">IELTS da <span>yuqori ball</span> olish uchun mashq qiling</div>
        <div className="hero-sub">Listening, Reading, Writing va Speaking bo'limlari bo'yicha to'liq tayyorgarlik</div>
        <div className="hero-stats">
          <div className="hero-stat"><div className="hero-stat-num">{(tests.listening?.length||0)+(tests.reading?.length||0)+(tests.writing?.length||0)+(tests.speaking?.length||0)}</div><div className="hero-stat-label">Jami testlar</div></div>
          <div className="hero-stat"><div className="hero-stat-num">{mocks.length}</div><div className="hero-stat-label">Full Mock</div></div>
          <div className="hero-stat"><div className="hero-stat-num">9.0</div><div className="hero-stat-label">Max Band</div></div>
        </div>
      </div>

      {isOwner && (
        <div className="owner-downloads">
          <div className="owner-dl-title">👑 Owner — Testlarni yuklab olish</div>
          <div className="owner-dl-row">
            {['listening','reading','writing','speaking'].map(s => (
              <button key={s} className="btn btn-owner btn-xs" onClick={() => downloadSection(s, tests[s]||[])}>
                ⬇ {s.charAt(0).toUpperCase()+s.slice(1)}
              </button>
            ))}
          </div>
        </div>
      )}

      {user && !user.premium && !isOwner && (
        <div className="premium-bar">
          <div style={{fontSize:'1.5rem'}}>👑</div>
          <div className="premium-bar-text">
            <div className="premium-bar-title">Premium testlarni ochish</div>
            <div className="premium-bar-sub">To'lov qiling va chekini yuboring — admin tasdiqlaydi</div>
          </div>
          <button className="btn btn-sm" style={{background:'#f59e0b',color:'#fff',flexShrink:0}} onClick={() => onNav('premium-request')}>Ochish →</button>
        </div>
      )}

      <div style={{fontWeight:800,fontSize:'0.8rem',textTransform:'uppercase',letterSpacing:'0.08em',color:'var(--muted)',marginBottom:'0.8rem'}}>Bo'limlar</div>
      <div className="section-grid">
        {sections.map(s => (
          <div key={s.key} className="section-card" style={{'--card-accent':s.color,'--card-accent-bg':s.bg}} onClick={() => user ? onNav(s.key) : onNav('auth')}>
            <div className="sc-icon">{s.icon}</div>
            <div className="sc-title">{s.label}</div>
            <div className="sc-count">{(tests[s.key]||[]).length} ta test</div>
            <div className="sc-arrow">›</div>
          </div>
        ))}
      </div>

      <div className="full-mock-banner" onClick={() => user ? onNav('fullmock') : onNav('auth')}>
        <div className="fm-icon">📋</div>
        <div>
          <div className="fm-title">Full Mock Test</div>
          <div className="fm-sub">Barcha 4 bo'lim — haqiqiy imtihon sharoitida</div>
        </div>
        <div className="fm-arrow">›</div>
      </div>
    </div>
  );
}

// ── SECTION PAGE (Listening / Reading / Writing / Speaking) ──
const SECTION_CONFIG = {
  listening: { icon: '🎧', label: 'Listening', gradient: 'linear-gradient(135deg,#10b981,#059669)', sub: 'Authentic audio materials with native speakers' },
  reading: { icon: '📖', label: 'Reading', gradient: 'linear-gradient(135deg,#3b82f6,#2563eb)', sub: 'Academic and General Training reading passages' },
  writing: { icon: '✍️', label: 'Writing', gradient: 'linear-gradient(135deg,#f59e0b,#d97706)', sub: 'Task 1 and Task 2 writing practice' },
  speaking: { icon: '🎤', label: 'Speaking', gradient: 'linear-gradient(135deg,#ef4444,#dc2626)', sub: 'Part 1, Part 2 and Part 3 speaking practice' },
};

function SectionPage({ sectionKey, user, onBack, onSelectTest, onNav }) {
  const cfg = SECTION_CONFIG[sectionKey];
  const allTests = store.get('rm2_tests', INITIAL_TESTS)[sectionKey] || [];
  const [filter, setFilter] = useState('all');
  const isOwner = user?.role === 'admin';

  const categories = [...new Set(allTests.map(t => t.category))];
  const freeTests = allTests.filter(t => t.type === 'free');
  const premiumTests = allTests.filter(t => t.type === 'premium');

  let filtered = filter === 'all' ? allTests : filter === 'premium' ? premiumTests : allTests.filter(t => t.category === filter);

  const canAccess = (t) => t.type === 'free' || user?.premium || isOwner;

  return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div className="page-header-bar" style={{background: cfg.gradient}}>
        <div className="phb-icon">{cfg.icon}</div>
        <div>
          <div className="phb-title">IELTS {cfg.label} Tests</div>
          <div className="phb-sub">{cfg.sub}</div>
        </div>
      </div>

      {isOwner && (
        <div className="owner-downloads" style={{marginBottom:'1rem'}}>
          <div className="owner-dl-title">👑 Ushbu bo'limni yuklab olish</div>
          <button className="btn btn-owner btn-sm" onClick={() => downloadSection(sectionKey, allTests)}>⬇ {cfg.label} testlarini yuklab olish</button>
        </div>
      )}

      <div className="filter-box">
        <div className="filter-label">Filter Tests</div>
        <div className="filter-options">
          <div className={`filter-opt ${filter==='all'?'active':''}`} onClick={() => setFilter('all')}>
            <div className="filter-opt-inner">⊞ All Tests</div>
            <span className="filter-count">{allTests.length}</span>
          </div>
          {categories.map(cat => (
            <div key={cat} className={`filter-opt ${filter===cat?'active':''}`} onClick={() => setFilter(cat)}>
              <div className="filter-opt-inner">📚 {cat}</div>
              <span className="filter-count">{allTests.filter(t=>t.category===cat).length}</span>
            </div>
          ))}
          {premiumTests.length > 0 && (
            <div className={`filter-opt ${filter==='premium'?'active':''}`} onClick={() => setFilter('premium')} style={filter!=='premium'?{color:'var(--purple)'}:{}}>
              <div className="filter-opt-inner">👑 Premium Tests</div>
              <span className="filter-count">{premiumTests.length}</span>
            </div>
          )}
        </div>
      </div>

      {/* Group by category if "all" */}
      {filter === 'all' ? (
        <div>
          {categories.map(cat => {
            const catFree = allTests.filter(t => t.category === cat && t.type === 'free');
            return catFree.length > 0 ? (
              <div key={cat}>
                <div className="list-section-header">
                  <span className="lsh-icon">📚</span>
                  <span className="lsh-title">{cat}</span>
                  <span className="lsh-count">({catFree.length} ta)</span>
                </div>
                <div className="tests-list">
                  {catFree.map(t => <TestItem key={t.id} t={t} canAccess={canAccess(t)} onStart={() => onSelectTest(t, sectionKey)} onUnlock={() => onNav('premium-request')} />)}
                </div>
              </div>
            ) : null;
          })}
          {premiumTests.length > 0 && (
            <div>
              <div className="premium-section-header">
                <span>👑</span>
                <span className="psh-title">Premium Tests</span>
                <span className="psh-count">{premiumTests.length} ta</span>
              </div>
              <div className="tests-list">
                {premiumTests.map(t => <TestItem key={t.id} t={t} canAccess={canAccess(t)} onStart={() => onSelectTest(t, sectionKey)} onUnlock={() => onNav('premium-request')} />)}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="tests-list">
          {filtered.map(t => <TestItem key={t.id} t={t} canAccess={canAccess(t)} onStart={() => onSelectTest(t, sectionKey)} onUnlock={() => onNav('premium-request')} />)}
        </div>
      )}
    </div>
  );
}

function TestItem({ t, canAccess, onStart, onUnlock }) {
  return (
    <div className={`test-item ${t.type==='premium'?'premium-item':''}`}>
      <div className="test-item-badges">
        <span className={`badge ${t.type==='free'?'badge-free':'badge-premium'}`}>
          {t.type==='free'?'✓ Free':'👑 Premium'}
        </span>
        <span className="badge badge-cat">{t.category}</span>
        {t.questions && <span className="badge badge-cat">✅ {t.questions}/40</span>}
      </div>
      <div className="test-item-title">{t.title}</div>
      <div className="test-item-desc">{t.description}</div>
      <div className="test-item-actions">
        {canAccess
          ? <button className="btn btn-green btn-sm w-full" style={{width:'100%',justifyContent:'center'}} onClick={onStart}>▶ Start</button>
          : <button className="btn btn-purple btn-sm w-full" style={{width:'100%',justifyContent:'center'}} onClick={onUnlock}>🔒 Unlock</button>}
      </div>
    </div>
  );
}

// ── FULL MOCK PAGE ──
function FullMockPage({ user, onBack, onSelectMock, onNav }) {
  const mocks = store.get('rm2_mocks', FULL_MOCKS);
  const canAccess = (t) => t.type === 'free' || user?.premium || user?.role === 'admin';
  return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div className="page-header-bar" style={{background:'linear-gradient(135deg,#0f172a,#1e3a5f)'}}>
        <div className="phb-icon">📋</div>
        <div>
          <div className="phb-title">Full Mock Tests</div>
          <div className="phb-sub">Complete IELTS simulation — all 4 sections, timed</div>
        </div>
      </div>
      <div className="mock-grid">
        {mocks.map(m => (
          <div key={m.id} className={`mock-card ${m.type==='premium'?'premium-item':''}`}>
            <div className="mock-card-header">
              <div>
                <div className="test-item-badges" style={{marginBottom:'0.4rem'}}>
                  <span className={`badge ${m.type==='free'?'badge-free':'badge-premium'}`}>{m.type==='free'?'✓ Free':'👑 Premium'}</span>
                </div>
                <div className="mock-card-title">{m.title}</div>
              </div>
              <div className="mock-duration">⏱ {m.duration}</div>
            </div>
            <div className="mock-card-desc">{m.description}</div>
            <div className="mock-sections-row">
              {m.sections.map(s => <span key={s} className="mock-section-tag">{s}</span>)}
            </div>
            {canAccess(m)
              ? <button className="btn btn-primary btn-sm" style={{width:'100%',justifyContent:'center'}} onClick={() => onSelectMock(m)}>▶ Start Full Mock</button>
              : <button className="btn btn-purple btn-sm" style={{width:'100%',justifyContent:'center'}} onClick={() => onNav('premium-request')}>🔒 Unlock</button>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── TEST TAKING ──
function TestTakingPage({ test, sectionKey, user, onBack }) {
  const cfg = SECTION_CONFIG[sectionKey] || SECTION_CONFIG.listening;
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [results, setResults] = useState(null);
  const [activePart, setActivePart] = useState(0);
  const setAns = (id, val) => setAnswers(a => ({ ...a, [id]: val }));
  const getAns = (id) => answers[id] || '';

  const sampleQs = [
    { id: 1, type: 'mcq', text: 'According to the passage, what is the main benefit described?', options: ['Economic growth', 'Environmental protection', 'Social development', 'Technological advancement'], answer: 'Environmental protection' },
    { id: 2, type: 'tf', text: 'The author believes current policies are sufficient.', answer: 'FALSE' },
    { id: 3, type: 'fill', text: 'The process involves ___ main stages.', answer: 'three' },
    { id: 4, type: 'mcq', text: 'Which of the following best describes the conclusion?', options: ['Pessimistic', 'Optimistic', 'Neutral', 'Contradictory'], answer: 'Optimistic' },
    { id: 5, type: 'tf', text: 'Further research is recommended in the final paragraph.', answer: 'TRUE' },
  ];

  function submit() {
    let correct = 0;
    const details = sampleQs.map(q => {
      const ua = getAns(q.id);
      const ok = ua.toLowerCase().trim() === q.answer.toLowerCase().trim();
      if (ok) correct++;
      return { ...q, userAnswer: ua, isCorrect: ok };
    });
    const band = Math.min(9, Math.max(1, ((correct / sampleQs.length) * 8 + 1))).toFixed(1);
    const res = { correct, total: sampleQs.length, band, details, testTitle: test.title, submittedAt: new Date().toISOString() };
    const subs = store.get('rm2_submissions', []);
    subs.push({ ...res, userId: user.id, userName: user.name });
    store.set('rm2_submissions', subs);
    setResults(res);
    setSubmitted(true);
  }

  if (submitted && results) return <ResultsPage results={results} testTitle={test.title} onBack={onBack} />;

  if (sectionKey === 'writing') return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div className="test-header-bar" style={{background:cfg.gradient}}>
        <div className="phb-title" style={{fontFamily:"'Instrument Serif',serif",color:'#fff',fontSize:'1.3rem',fontWeight:400}}>{test.title}</div>
      </div>
      <div className="test-body">
        <div className="test-body-inner">
          <WritingContent data={test} getAns={getAns} setAns={setAns} />
          <div className="divider" />
          <button className="btn btn-primary" style={{width:'100%',justifyContent:'center',padding:'0.8rem'}} onClick={submit}>Topshirish →</button>
        </div>
      </div>
    </div>
  );

  if (sectionKey === 'speaking') return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div className="test-header-bar" style={{background:cfg.gradient}}>
        <div className="phb-title" style={{fontFamily:"'Instrument Serif',serif",color:'#fff',fontSize:'1.3rem',fontWeight:400}}>{test.title}</div>
      </div>
      <div className="test-body">
        <div className="test-body-inner">
          <SpeakingContent data={test} />
          <div className="divider" />
          <button className="btn btn-primary" style={{width:'100%',justifyContent:'center',padding:'0.8rem'}} onClick={submit}>Tugatish →</button>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div className="test-header-bar" style={{background:cfg.gradient}}>
        <div className="phb-title" style={{fontFamily:"'Instrument Serif',serif",color:'#fff',fontSize:'1.3rem',fontWeight:400}}>{test.title}</div>
        <div style={{color:'rgba(255,255,255,0.7)',fontSize:'0.82rem',marginTop:'0.2rem'}}>{sampleQs.length} ta savol</div>
      </div>
      {sectionKey === 'listening' && (
        <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:'14px',padding:'1rem 1.2rem',marginBottom:'1.2rem'}}>
          <div style={{fontWeight:700,color:'var(--text)',marginBottom:'0.5rem',fontSize:'0.9rem'}}>🎧 Audio</div>
          <div style={{background:'var(--bg)',borderRadius:'10px',padding:'1rem',textAlign:'center',fontSize:'0.83rem',color:'var(--muted)'}}>Audio fayl admin tomonidan yuklanadi. Savollarni o'z bilimingiz asosida javob bering.</div>
        </div>
      )}
      {sectionKey === 'reading' && (
        <div className="passage-box">
          <strong style={{display:'block',marginBottom:'0.8rem',color:'var(--accent)'}}>{test.title}</strong>
          {test.description}\n\nThis is a sample reading passage. In a real test, a full academic or general training passage would appear here. The passage would be approximately 700-900 words covering the topic described above. Students should read carefully and answer the questions based on the information provided in the passage, using evidence from the text to support their answers. Questions may ask about specific details, general understanding, vocabulary in context, or the writer's purpose and opinion.\n\nFurther paragraphs would extend the discussion with examples, data, and expert opinions to provide a comprehensive treatment of the subject matter for IELTS band score assessment purposes.
        </div>
      )}
      <div className="test-body">
        <div className="test-body-inner">
          {sampleQs.map(q => <QBlock key={q.id} q={q} getAns={getAns} setAns={setAns} />)}
          <div className="divider" />
          <button className="btn btn-primary" style={{width:'100%',justifyContent:'center',padding:'0.8rem'}} onClick={submit}>Topshirish va natijani ko'rish →</button>
        </div>
      </div>
    </div>
  );
}

function QBlock({ q, getAns, setAns, showResult }) {
  const ans = getAns(q.id);
  const cls = showResult ? (q.isCorrect ? 'correct' : 'incorrect') : '';
  return (
    <div className={`q-block ${cls}`}>
      <div className="q-num">Savol {q.id}</div>
      <div className="q-text">{q.text}</div>
      {q.type === 'mcq' && q.options.map(opt => {
        let c = '';
        if (showResult) { if (opt===q.answer) c='correct-ans'; else if (opt===ans&&opt!==q.answer) c='wrong-ans'; }
        else if (opt===ans) c='selected';
        return <div key={opt} className={`opt ${c}`} onClick={() => !showResult && setAns(q.id, opt)}><div className="opt-dot"/>{opt}</div>;
      })}
      {q.type === 'tf' && ['TRUE','FALSE','NOT GIVEN'].map(opt => {
        let c = '';
        if (showResult) { if (opt===q.answer) c='correct-ans'; else if (opt===ans&&opt!==q.answer) c='wrong-ans'; }
        else if (opt===ans) c='selected';
        return <div key={opt} className={`opt ${c}`} onClick={() => !showResult && setAns(q.id, opt)}><div className="opt-dot"/>{opt}</div>;
      })}
      {q.type === 'fill' && (
        <div>
          <input type="text" placeholder="Javobingizni yozing..." value={showResult?q.userAnswer||'':ans} readOnly={showResult}
            onChange={e => setAns(q.id, e.target.value)}
            style={{width:'100%',padding:'0.65rem 0.9rem',border:`1.5px solid ${showResult?(q.isCorrect?'var(--green)':'var(--red)'):'var(--border)'}`,borderRadius:'9px',fontSize:'0.88rem',background:showResult?(q.isCorrect?'#f0fdf4':'#fef2f2'):'#fff',outline:'none'}}
          />
          {showResult&&!q.isCorrect&&<div style={{marginTop:'0.4rem',fontSize:'0.78rem',color:'var(--green)'}}>To'g'ri javob: <strong>{q.answer}</strong></div>}
        </div>
      )}
    </div>
  );
}

function WritingContent({ data, getAns, setAns }) {
  const t1 = getAns('task1'), t2 = getAns('task2');
  const wc = t => t.trim() ? t.trim().split(/\s+/).length : 0;
  const prompts = {
    task1: data.description + ' (Task 1 — kamida 150 so\'z yozing)',
    task2: 'Task 2 — muammoni muhokama qiling va o\'z fikringizni bildiring. Kamida 250 so\'z yozing.'
  };
  return (
    <div>
      <div style={{fontWeight:800,color:'var(--text)',marginBottom:'0.7rem'}}>Task 1</div>
      <div className="writing-prompt-box">{prompts.task1}</div>
      <textarea className="writing-ta" style={{minHeight:'160px'}} placeholder="Task 1 javobingizni shu yerga yozing..." value={t1} onChange={e=>setAns('task1',e.target.value)} />
      <div className="wc" style={{color:wc(t1)>=150?'var(--green)':'var(--red)'}}>{wc(t1)} / 150 so'z</div>
      <div style={{height:'1.5rem'}} />
      <div style={{fontWeight:800,color:'var(--text)',marginBottom:'0.7rem'}}>Task 2</div>
      <div className="writing-prompt-box">{prompts.task2}</div>
      <textarea className="writing-ta" style={{minHeight:'220px'}} placeholder="Task 2 javobingizni shu yerga yozing..." value={t2} onChange={e=>setAns('task2',e.target.value)} />
      <div className="wc" style={{color:wc(t2)>=250?'var(--green)':'var(--red)'}}>{wc(t2)} / 250 so'z</div>
    </div>
  );
}

function SpeakingContent({ data }) {
  const [part, setPart] = useState('p1');
  const [timer, setTimer] = useState(60);
  const [running, setRunning] = useState(false);
  const [rec, setRec] = useState(false);
  const ref = useRef();
  useEffect(() => {
    if (running && timer > 0) { ref.current = setTimeout(() => setTimer(t => t - 1), 1000); }
    else if (timer === 0) setRunning(false);
    return () => clearTimeout(ref.current);
  }, [running, timer]);
  const fmt = s => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;
  const q1 = ['Qayerda yashasiz?', 'Kundalik hayotingizni tasvirlab bering.', 'Bo\'sh vaqtingizda nima qilasiz?'];
  const q3 = ['Jamiyatda texnologiyaning roli nima?', 'Yoshlar qanday ko\'nikmalarni egallashi kerak?', 'Kelajakda ta\'lim qanday o\'zgaradi?'];

  return (
    <div>
      <div style={{display:'flex',gap:'0.5rem',marginBottom:'1.2rem'}}>
        {[['p1','Part 1'],['p2','Part 2'],['p3','Part 3']].map(([k,l]) => (
          <button key={k} className={`btn btn-sm ${part===k?'btn-primary':'btn-ghost'}`} onClick={() => { setPart(k); setTimer(60); setRunning(false); setRec(false); }}>{l}</button>
        ))}
      </div>
      {part==='p1' && q1.map((q,i) => <div key={i} className="sp-card"><div style={{fontSize:'0.7rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.08em',color:'var(--accent)',marginBottom:'0.35rem'}}>Savol {i+1}</div><div className="sp-q">{q}</div></div>)}
      {part==='p2' && (
        <div>
          <div className="cue-box">Bir muhim voqeani tasvirlab bering.\n\nSiz aytishingiz kerak:\n• Bu qachon sodir bo'ldi\n• Kim ishtirok etdi\n• Nima bo'ldi\n• Nima uchun bu siz uchun muhim edi</div>
          <div style={{textAlign:'center'}}>
            <div style={{fontSize:'0.78rem',color:'var(--muted)',marginBottom:'0.3rem'}}>Tayyorgarlik vaqti</div>
            <div className={`timer-big ${timer<=10?'warn':''}`}>{fmt(timer)}</div>
            <div style={{display:'flex',gap:'0.5rem',justifyContent:'center',marginBottom:'1.2rem'}}>
              <button className="btn btn-green btn-sm" onClick={() => setRunning(r=>!r)}>{running?'Pauza':'Boshlash'}</button>
              <button className="btn btn-ghost btn-sm" onClick={() => { setTimer(60); setRunning(false); }}>Reset</button>
            </div>
            <div style={{fontSize:'0.78rem',color:'var(--muted)',marginBottom:'0.5rem'}}>Yozib olish</div>
            <button className={`mic-btn ${rec?'rec':'idle'}`} onClick={() => setRec(r=>!r)}>{rec?'⏹':'🎤'}</button>
            <div style={{textAlign:'center',fontSize:'0.78rem',color:'var(--muted)'}}>{rec?'● Yozib olinmoqda... to\'xtatish uchun bosing':'Mikrofon tugmasini bosing'}</div>
          </div>
        </div>
      )}
      {part==='p3' && q3.map((q,i) => <div key={i} className="sp-card"><div style={{fontSize:'0.7rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.08em',color:'var(--accent)',marginBottom:'0.35rem'}}>Munozara {i+1}</div><div className="sp-q">{q}</div></div>)}
    </div>
  );
}

// ── RESULTS ──
function ResultsPage({ results, testTitle, onBack }) {
  const { correct, total, band, details } = results;
  const [sec, setSec] = useState('questions');
  return (
    <div>
      <div className="back-btn" onClick={onBack}>← Testlar ro'yxatiga qaytish</div>
      <div className="result-hero">
        <div>
          <div style={{fontSize:'0.72rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.1em',color:'rgba(255,255,255,0.6)',marginBottom:'0.3rem'}}>Taxminiy ball</div>
          <div className="result-band">{band} <small>/ 9.0</small></div>
        </div>
        <div style={{width:'1px',height:'60px',background:'rgba(255,255,255,0.2)'}} />
        <div className="result-info">
          <h2>{testTitle}</h2>
          <p>{correct} / {total} savol to'g'ri ({Math.round(correct/Math.max(total,1)*100)}%)</p>
        </div>
      </div>
      <div className="test-body">
        <div className="test-body-inner">
          <div style={{fontWeight:700,color:'var(--text)',marginBottom:'1rem'}}>Natijalarni ko'rib chiqish</div>
          {details?.map(q => (
            <div key={q.id} className={`q-block ${q.isCorrect?'correct':'incorrect'}`}>
              <div className="q-num">Savol {q.id} — {q.isCorrect?'✓ To\'g\'ri':'✗ Noto\'g\'ri'}</div>
              <div className="q-text">{q.text}</div>
              {q.type==='mcq'&&q.options.map(opt=><div key={opt} className={`opt ${opt===q.answer?'correct-ans':opt===q.userAnswer&&opt!==q.answer?'wrong-ans':''}`}><div className="opt-dot"/>{opt}</div>)}
              {q.type==='tf'&&['TRUE','FALSE','NOT GIVEN'].map(opt=><div key={opt} className={`opt ${opt===q.answer?'correct-ans':opt===q.userAnswer&&opt!==q.answer?'wrong-ans':''}`}><div className="opt-dot"/>{opt}</div>)}
              {q.type==='fill'&&<div><div style={{padding:'0.6rem 0.9rem',borderRadius:'8px',background:q.isCorrect?'#f0fdf4':'#fef2f2',fontSize:'0.88rem',border:`1.5px solid ${q.isCorrect?'var(--green)':'var(--red)'}`}}>Sizning javobingiz: <strong>{q.userAnswer||'(javob yo\'q)'}</strong></div>{!q.isCorrect&&<div style={{marginTop:'0.35rem',fontSize:'0.75rem',color:'var(--green)'}}>To'g'ri javob: <strong>{q.answer}</strong></div>}</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── PREMIUM REQUEST ──
function PremiumRequestPage({ user, onBack }) {
  const [file, setFile] = useState(null);
  const [note, setNote] = useState('');
  const [done, setDone] = useState(false);
  const fileRef = useRef();
  const existing = store.get('rm2_requests', []).find(r => r.userId === user.id && r.status === 'pending');

  if (done || existing) return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div style={{textAlign:'center',padding:'3rem',background:'#fff',borderRadius:'20px',border:'1.5px solid var(--border)'}}>
        <div style={{fontSize:'3rem',marginBottom:'1rem'}}>⏳</div>
        <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.4rem',color:'var(--text)',marginBottom:'0.5rem'}}>So'rovingiz yuborildi</div>
        <p style={{color:'var(--muted)',maxWidth:'340px',margin:'0 auto'}}>Chek tekshirilgandan so'ng, owner premium huquqini beradi.</p>
      </div>
    </div>
  );

  function submit() {
    if (!file) return;
    const reqs = store.get('rm2_requests', []);
    reqs.push({ id: Date.now().toString(), userId: user.id, userName: user.name, userEmail: user.email, note, fileName: file.name, status: 'pending', submittedAt: new Date().toISOString() });
    store.set('rm2_requests', reqs);
    setDone(true);
  }

  return (
    <div>
      <div className="back-btn" onClick={onBack}>← Orqaga</div>
      <div style={{background:'#fff',borderRadius:'20px',border:'1.5px solid var(--border)',overflow:'hidden'}}>
        <div style={{background:'linear-gradient(135deg,var(--purple),#7c3aed)',padding:'1.8rem'}}>
          <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.4rem',color:'#fff',fontWeight:400}}>👑 Premium Huquq Olish</div>
          <div style={{color:'rgba(255,255,255,0.65)',fontSize:'0.82rem',marginTop:'0.3rem'}}>To'lov chekingizni yuboring</div>
        </div>
        <div style={{padding:'1.8rem'}}>
          <div style={{background:'#fef3c7',border:'1.5px solid #fcd34d',borderRadius:'12px',padding:'1rem 1.2rem',marginBottom:'1.5rem',fontSize:'0.85rem',color:'#92400e',lineHeight:'1.6'}}>
            💳 <strong>To'lov yo'riqnomasi:</strong> Quyidagi raqamga to'lov qiling va chek rasmini yuklang. Admin tekshirib, 24 soat ichida aktivlashtiradi.
          </div>
          <div className="field">
            <label>To'lov cheki (rasm yoki PDF)</label>
            <div className={`upload-zone ${file?'has-file':''}`} onClick={() => fileRef.current.click()}>
              {file
                ? <><div style={{fontSize:'2rem'}}>✅</div><div style={{fontWeight:600,color:'var(--green)',marginTop:'0.3rem'}}>{file.name}</div><div style={{fontSize:'0.75rem',color:'var(--muted)',marginTop:'0.2rem'}}>O'zgartirish uchun bosing</div></>
                : <><div style={{fontSize:'2rem',marginBottom:'0.4rem'}}>📎</div><div style={{fontWeight:600,color:'var(--text)'}}>Chek rasmini yuklang</div><div style={{fontSize:'0.75rem',color:'var(--muted)',marginTop:'0.2rem'}}>PNG, JPG yoki PDF</div></>}
              <input ref={fileRef} type="file" accept="image/*,.pdf" style={{display:'none'}} onChange={e=>setFile(e.target.files[0])} />
            </div>
          </div>
          <div className="field">
            <label>Qo'shimcha izoh (ixtiyoriy)</label>
            <textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Qo'shimcha ma'lumot..." style={{width:'100%',border:'1.5px solid var(--border)',borderRadius:'10px',padding:'0.7rem 0.9rem',fontSize:'0.88rem',minHeight:'70px',outline:'none',resize:'vertical'}} />
          </div>
          <button className="btn btn-purple" style={{width:'100%',justifyContent:'center',padding:'0.8rem',fontSize:'0.92rem'}} onClick={submit} disabled={!file}>
            Chekni yuborish →
          </button>
        </div>
      </div>
    </div>
  );
}

// ── PROFILE ──
function ProfilePage({ user, onNav }) {
  const subs = store.get('rm2_submissions', []).filter(s => s.userId === user.id);
  const req = store.get('rm2_requests', []).find(r => r.userId === user.id);
  return (
    <div>
      <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.6rem',marginBottom:'0.3rem',fontWeight:400}}>Mening sahifam</div>
      <div style={{color:'var(--muted)',fontSize:'0.85rem',marginBottom:'1.5rem'}}>{user.email}</div>
      <div className="stats-grid">
        <div className="stat-box"><div className="stat-n">{subs.length}</div><div className="stat-l">Testlar</div></div>
        <div className="stat-box"><div className="stat-n">{subs.length?(subs.reduce((a,s)=>a+parseFloat(s.band),0)/subs.length).toFixed(1):'—'}</div><div className="stat-l">O'rt. Ball</div></div>
        <div className="stat-box"><div className="stat-n">{user.premium?'⭐':'🆓'}</div><div className="stat-l">{user.premium?'Premium':'Free'}</div></div>
      </div>
      {!user.premium && (
        <div className="premium-bar" style={{marginBottom:'1.5rem'}}>
          <div style={{fontSize:'1.3rem'}}>👑</div>
          <div className="premium-bar-text">
            <div className="premium-bar-title">Premium holat: {req?<span className={`chip chip-${req.status}`}>{req.status==='pending'?'Ko\'rib chiqilmoqda':req.status==='approved'?'Tasdiqlandi':'Rad etildi'}</span>:'Yo\'q'}</div>
            {!req && <div className="premium-bar-sub">Premium testlarni ochish uchun to'lov qiling</div>}
          </div>
          {!req && <button className="btn btn-sm" style={{background:'#f59e0b',color:'#fff',flexShrink:0}} onClick={()=>onNav('premium-request')}>Ochish →</button>}
        </div>
      )}
      <div style={{fontWeight:800,fontSize:'0.85rem',color:'var(--text)',marginBottom:'0.8rem'}}>Test tarixi</div>
      {subs.length===0
        ? <div className="empty-state"><div className="empty-icon">📋</div><p>Hali test topshirmadingiz.</p></div>
        : <div style={{background:'#fff',borderRadius:'16px',border:'1.5px solid var(--border)',overflow:'hidden'}}>
            <div className="tbl-wrap">
              <table>
                <thead><tr><th>Test</th><th>Ball</th><th>Natija</th><th>Sana</th></tr></thead>
                <tbody>
                  {subs.map((s,i)=>(
                    <tr key={i}>
                      <td style={{fontWeight:600,maxWidth:'200px'}}>{s.testTitle}</td>
                      <td><span style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.2rem',color:'var(--accent)'}}>{s.band}</span></td>
                      <td style={{color:'var(--muted)'}}>{s.correct}/{s.total}</td>
                      <td style={{color:'var(--muted)',fontSize:'0.78rem'}}>{new Date(s.submittedAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>}
    </div>
  );
}


// ── USERS PANEL (admin) ──
function UsersPanel({ users: initialUsers, setUsers }) {
  const [emailInput, setEmailInput] = useState('');
  const [msg, setMsg] = useState('');
  const [msgType, setMsgType] = useState('');
  const [localUsers, setLocalUsers] = useState(initialUsers);

  function grantByEmail() {
    const email = emailInput.trim().toLowerCase();
    if (!email) { setMsg("Email kiriting."); setMsgType('err'); return; }
    const all = store.get('rm2_users', []);
    const idx = all.findIndex(u => u.email === email);
    if (idx === -1) { setMsg(`"${email}" — bu email ro'yxatdan o'tmagan.`); setMsgType('err'); return; }
    if (all[idx].premium) { setMsg(`${all[idx].name} allaqachon Premium foydalanuvchi.`); setMsgType('warn'); return; }
    all[idx].premium = true;
    store.set('rm2_users', all);
    setUsers(all);
    setLocalUsers(all);
    setMsg(`✅ ${all[idx].name} (${email}) ga Premium muvaffaqiyatli berildi!`);
    setMsgType('ok');
    setEmailInput('');
  }

  function revokeByEmail() {
    const email = emailInput.trim().toLowerCase();
    if (!email) { setMsg("Email kiriting."); setMsgType('err'); return; }
    const all = store.get('rm2_users', []);
    const idx = all.findIndex(u => u.email === email);
    if (idx === -1) { setMsg(`"${email}" topilmadi.`); setMsgType('err'); return; }
    all[idx].premium = false;
    store.set('rm2_users', all);
    setUsers(all);
    setLocalUsers(all);
    setMsg(`✔ ${all[idx].name} ning Premium huquqi bekor qilindi.`);
    setMsgType('ok');
    setEmailInput('');
  }

  function togglePremium(uid) {
    const updated = localUsers.map(u => u.id===uid ? {...u, premium:!u.premium} : u);
    store.set('rm2_users', updated);
    setUsers(updated);
    setLocalUsers(updated);
  }

  const premiumCount = localUsers.filter(u => u.premium).length;

  return (
    <div>
      <div className="admin-panel-title">Foydalanuvchilarni boshqarish</div>

      {/* EMAIL PREMIUM BOX */}
      <div style={{background:'linear-gradient(135deg,#f0fdf4,#dcfce7)',border:'2px solid #86efac',borderRadius:'16px',padding:'1.4rem',marginBottom:'1.5rem'}}>
        <div style={{fontWeight:800,color:'#166534',fontSize:'0.88rem',marginBottom:'0.3rem',display:'flex',alignItems:'center',gap:'0.4rem'}}>
          ⭐ Email orqali Premium berish / bekor qilish
        </div>
        <div style={{fontSize:'0.78rem',color:'#15803d',marginBottom:'1rem'}}>
          To'lov qilgan foydalanuvchining emailini kiriting va Premium bering
        </div>
        <div style={{display:'flex',gap:'0.6rem',flexWrap:'wrap',alignItems:'flex-end'}}>
          <div style={{flex:1,minWidth:'200px'}}>
            <div style={{fontSize:'0.72rem',fontWeight:700,color:'#166534',marginBottom:'0.35rem',textTransform:'uppercase',letterSpacing:'0.06em'}}>Foydalanuvchi emaili</div>
            <input
              type="email"
              placeholder="example@gmail.com"
              value={emailInput}
              onChange={e => { setEmailInput(e.target.value); setMsg(''); }}
              onKeyDown={e => e.key === 'Enter' && grantByEmail()}
              style={{width:'100%',padding:'0.65rem 0.9rem',border:'1.5px solid #86efac',borderRadius:'10px',fontSize:'0.88rem',outline:'none',background:'#fff'}}
            />
          </div>
          <button className="btn btn-green btn-sm" onClick={grantByEmail} style={{flexShrink:0}}>
            ⭐ Premium Berish
          </button>
          <button className="btn btn-ghost btn-sm" onClick={revokeByEmail} style={{flexShrink:0,borderColor:'#fca5a5',color:'#dc2626'}}>
            ✕ Bekor Qilish
          </button>
        </div>
        {msg && (
          <div style={{marginTop:'0.8rem',padding:'0.6rem 0.9rem',borderRadius:'8px',fontSize:'0.82rem',fontWeight:600,
            background: msgType==='ok'?'#dcfce7':msgType==='warn'?'#fef9c3':'#fee2e2',
            color: msgType==='ok'?'#166534':msgType==='warn'?'#854d0e':'#dc2626',
            border: `1px solid ${msgType==='ok'?'#86efac':msgType==='warn'?'#fde047':'#fca5a5'}`
          }}>
            {msg}
          </div>
        )}
      </div>

      {/* STATS ROW */}
      <div style={{display:'flex',gap:'0.8rem',marginBottom:'1.2rem',flexWrap:'wrap'}}>
        <div style={{background:'var(--bg)',borderRadius:'10px',padding:'0.8rem 1.2rem',border:'1.5px solid var(--border)',textAlign:'center',minWidth:'100px'}}>
          <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.6rem',color:'var(--accent)'}}>{localUsers.length}</div>
          <div style={{fontSize:'0.7rem',color:'var(--muted)',fontWeight:700,textTransform:'uppercase'}}>Jami</div>
        </div>
        <div style={{background:'#f0fdf4',borderRadius:'10px',padding:'0.8rem 1.2rem',border:'1.5px solid #86efac',textAlign:'center',minWidth:'100px'}}>
          <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.6rem',color:'#16a34a'}}>{premiumCount}</div>
          <div style={{fontSize:'0.7rem',color:'#15803d',fontWeight:700,textTransform:'uppercase'}}>Premium</div>
        </div>
        <div style={{background:'var(--bg)',borderRadius:'10px',padding:'0.8rem 1.2rem',border:'1.5px solid var(--border)',textAlign:'center',minWidth:'100px'}}>
          <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.6rem',color:'var(--muted)'}}>{localUsers.length - premiumCount}</div>
          <div style={{fontSize:'0.7rem',color:'var(--muted)',fontWeight:700,textTransform:'uppercase'}}>Bepul</div>
        </div>
      </div>

      {/* USER TABLE */}
      {localUsers.length === 0
        ? <div className="empty-state"><div className="empty-icon">👥</div><p>Hali ro'yxatdan o'tgan foydalanuvchi yo'q.</p></div>
        : <div className="tbl-wrap">
            <table>
              <thead><tr><th>Ism</th><th>Email</th><th>Holat</th><th>Qo'shilgan</th><th>Amal</th></tr></thead>
              <tbody>
                {localUsers.map(u => (
                  <tr key={u.id}>
                    <td style={{fontWeight:600}}>{u.name}</td>
                    <td style={{color:'var(--muted)',fontSize:'0.8rem'}}>{u.email}</td>
                    <td>
                      <span className={`chip chip-${u.premium?'premium':'free'}`}>
                        {u.premium ? '⭐ Premium' : '🆓 Bepul'}
                      </span>
                    </td>
                    <td style={{color:'var(--muted)',fontSize:'0.78rem'}}>{u.joined ? new Date(u.joined).toLocaleDateString() : '—'}</td>
                    <td>
                      <button
                        className={`btn btn-xs ${u.premium ? 'btn-ghost' : 'btn-green'}`}
                        style={u.premium ? {borderColor:'#fca5a5',color:'#dc2626'} : {}}
                        onClick={() => togglePremium(u.id)}
                      >
                        {u.premium ? 'Bekor qilish' : '⭐ Premium berish'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
      }
    </div>
  );
}

// ── ADMIN ──
function AdminPanel({ user, onNav }) {
  if (user?.role !== 'admin') return <div className="empty-state"><div className="empty-icon">🚫</div><p>Ruxsat yo'q.</p></div>;
  const [sec, setSec] = useState('dashboard');
  const [tests, setTests] = useState(store.get('rm2_tests', INITIAL_TESTS));
  const [users, setUsers] = useState(store.get('rm2_users', []));
  const [requests, setRequests] = useState(store.get('rm2_requests', []));
  const [mocks, setMocks] = useState(store.get('rm2_mocks', FULL_MOCKS));
  const [showAdd, setShowAdd] = useState(false);
  const subs = store.get('rm2_submissions', []);
  const pending = requests.filter(r => r.status === 'pending').length;

  const refresh = () => { setTests(store.get('rm2_tests',INITIAL_TESTS)); setUsers(store.get('rm2_users',[])); setRequests(store.get('rm2_requests',[])); setMocks(store.get('rm2_mocks',FULL_MOCKS)); };

  function handleReq(id, action) {
    const reqs = requests.map(r => r.id===id?{...r,status:action}:r);
    store.set('rm2_requests', reqs);
    if (action==='approved') {
      const req = requests.find(r=>r.id===id);
      const usrs = users.map(u=>u.id===req.userId?{...u,premium:true}:u);
      store.set('rm2_users', usrs); setUsers(usrs);
    }
    setRequests(reqs);
  }
  function togglePremium(uid) {
    const updated = users.map(u=>u.id===uid?{...u,premium:!u.premium}:u);
    store.set('rm2_users',updated); setUsers(updated);
  }
  function deleteTest(sectionKey, id) {
    const updated = {...tests,[sectionKey]:tests[sectionKey].filter(t=>t.id!==id)};
    store.set('rm2_tests',updated); setTests(updated);
  }
  function toggleTestType(sectionKey, id) {
    const updated = {...tests,[sectionKey]:tests[sectionKey].map(t=>t.id===id?{...t,type:t.type==='free'?'premium':'free'}:t)};
    store.set('rm2_tests',updated); setTests(updated);
  }

  const allTests = [...(tests.listening||[]),...(tests.reading||[]),...(tests.writing||[]),...(tests.speaking||[])];
  const navItems = [
    {id:'dashboard',icon:'📊',label:'Dashboard'},
    {id:'tests',icon:'📝',label:'Testlar'},
    {id:'mocks',icon:'📋',label:'Full Mock'},
    {id:'users',icon:'👥',label:`Foydalanuvchilar (${users.length})`},
    {id:'requests',icon:'📨',label:`So'rovlar${pending?` (${pending})`:''}`},
    {id:'submissions',icon:'📈',label:'Natijalar'},
  ];

  return (
    <div>
      <div className="flex items-center justify-between" style={{marginBottom:'1.2rem',flexWrap:'wrap',gap:'0.8rem'}}>
        <div>
          <div style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.5rem',fontWeight:400}}>👑 Admin Panel</div>
          <div style={{color:'var(--muted)',fontSize:'0.8rem'}}>{OWNER_EMAIL} — Faqat siz ko'ra olasiz</div>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={()=>onNav('home')}>← Saytga qaytish</button>
      </div>
      <div className="admin-layout">
        <div className="admin-sidebar">
          <div className="admin-sidebar-title">Menu</div>
          {navItems.map(n=>(
            <div key={n.id} className={`a-nav-item ${sec===n.id?'active':''}`} onClick={()=>{setSec(n.id);refresh();}}>
              {n.icon} {n.label}
            </div>
          ))}
        </div>
        <div className="admin-panel">
          {sec==='dashboard' && (
            <div>
              <div className="admin-panel-title">Umumiy ko'rinish</div>
              <div className="stats-grid">
                <div className="stat-box"><div className="stat-n">{allTests.length}</div><div className="stat-l">Testlar</div></div>
                <div className="stat-box"><div className="stat-n">{users.length}</div><div className="stat-l">Foydalanuvchilar</div></div>
                <div className="stat-box"><div className="stat-n">{users.filter(u=>u.premium).length}</div><div className="stat-l">Premium</div></div>
                <div className="stat-box"><div className="stat-n">{pending}</div><div className="stat-l">Kutilmoqda</div></div>
                <div className="stat-box"><div className="stat-n">{subs.length}</div><div className="stat-l">Natijalar</div></div>
              </div>
              {pending>0&&<div style={{background:'#fef3c7',border:'1.5px solid #fcd34d',borderRadius:'12px',padding:'1rem 1.2rem'}}>
                <div style={{fontWeight:700,color:'#92400e'}}>⚠ {pending} ta so'rov kutilmoqda</div>
                <button className="btn btn-sm btn-primary mt-1" style={{marginTop:'0.5rem'}} onClick={()=>setSec('requests')}>Ko'rib chiqish →</button>
              </div>}
            </div>
          )}

          {sec==='tests' && (
            <div>
              <div className="admin-panel-title">Testlarni boshqarish</div>
              {['listening','reading','writing','speaking'].map(sk => (
                <div key={sk} style={{marginBottom:'1.5rem'}}>
                  <div style={{fontWeight:800,fontSize:'0.82rem',textTransform:'uppercase',letterSpacing:'0.07em',color:'var(--muted)',marginBottom:'0.6rem',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    {sk.toUpperCase()} ({(tests[sk]||[]).length})
                    <button className="btn btn-primary btn-xs" onClick={()=>setShowAdd(sk)}>+ Qo'shish</button>
                  </div>
                  <div className="tbl-wrap">
                    <table>
                      <thead><tr><th>Nomi</th><th>Turi</th><th>Yuklab olish</th><th>Amallar</th></tr></thead>
                      <tbody>
                        {(tests[sk]||[]).map(t=>(
                          <tr key={t.id}>
                            <td style={{fontWeight:600,maxWidth:'180px'}}>{t.title}</td>
                            <td><span className={`chip chip-${t.type}`}>{t.type}</span></td>
                            <td><button className="btn btn-owner btn-xs" onClick={()=>downloadSection(sk,[t])}>⬇</button></td>
                            <td><div className="flex gap-1">
                              <button className="btn btn-ghost btn-xs" onClick={()=>toggleTestType(sk,t.id)}>{t.type==='free'?'→ Premium':'→ Free'}</button>
                              <button className="btn btn-danger btn-xs" onClick={()=>deleteTest(sk,t.id)}>O'chirish</button>
                            </div></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}

          {sec==='mocks' && (
            <div>
              <div className="admin-panel-title">Full Mock Testlar</div>
              <div className="tbl-wrap">
                <table>
                  <thead><tr><th>Nomi</th><th>Turi</th><th>Davomiyligi</th></tr></thead>
                  <tbody>
                    {mocks.map(m=>(
                      <tr key={m.id}>
                        <td style={{fontWeight:600}}>{m.title}</td>
                        <td><span className={`chip chip-${m.type}`}>{m.type}</span></td>
                        <td style={{color:'var(--muted)'}}>{m.duration}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {sec==='users' && <UsersPanel users={users} setUsers={setUsers} />}

          {sec==='requests' && (
            <div>
              <div className="admin-panel-title">Premium So'rovlar</div>
              {requests.length===0?<div className="empty-state"><div className="empty-icon">📨</div><p>Hali so'rov yo'q.</p></div>:(
                <div className="tbl-wrap">
                  <table>
                    <thead><tr><th>Foydalanuvchi</th><th>Email</th><th>Chek</th><th>Holat</th><th>Sana</th><th>Amallar</th></tr></thead>
                    <tbody>
                      {requests.map(r=>(
                        <tr key={r.id}>
                          <td style={{fontWeight:600}}>{r.userName}</td>
                          <td style={{color:'var(--muted)',fontSize:'0.78rem'}}>{r.userEmail}</td>
                          <td style={{color:'var(--muted)',fontSize:'0.78rem'}}>📎 {r.fileName}</td>
                          <td><span className={`chip chip-${r.status}`}>{r.status==='pending'?'Kutilmoqda':r.status==='approved'?'Tasdiqlandi':'Rad etildi'}</span></td>
                          <td style={{color:'var(--muted)',fontSize:'0.78rem'}}>{new Date(r.submittedAt).toLocaleDateString()}</td>
                          <td>{r.status==='pending'
                            ?<div className="flex gap-1">
                              <button className="btn btn-green btn-xs" onClick={()=>handleReq(r.id,'approved')}>✓</button>
                              <button className="btn btn-danger btn-xs" onClick={()=>handleReq(r.id,'rejected')}>✗</button>
                            </div>
                            :<span style={{color:'var(--muted)',fontSize:'0.75rem'}}>Bajarildi</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {sec==='submissions' && (
            <div>
              <div className="admin-panel-title">Barcha natijalar ({subs.length})</div>
              {subs.length===0?<div className="empty-state"><div className="empty-icon">📈</div><p>Hali natija yo'q.</p></div>:(
                <div className="tbl-wrap">
                  <table>
                    <thead><tr><th>Foydalanuvchi</th><th>Test</th><th>Ball</th><th>Natija</th><th>Sana</th></tr></thead>
                    <tbody>
                      {subs.map((s,i)=>(
                        <tr key={i}>
                          <td style={{fontWeight:600}}>{s.userName}</td>
                          <td style={{fontSize:'0.82rem'}}>{s.testTitle}</td>
                          <td><span style={{fontFamily:"'Instrument Serif',serif",fontSize:'1.2rem',color:'var(--accent)'}}>{s.band}</span></td>
                          <td style={{color:'var(--muted)'}}>{s.correct}/{s.total}</td>
                          <td style={{color:'var(--muted)',fontSize:'0.78rem'}}>{new Date(s.submittedAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {showAdd && <AddTestModal sectionKey={showAdd} onClose={()=>setShowAdd(false)} onSave={t=>{const updated={...tests,[showAdd]:[...(tests[showAdd]||[]),t]};store.set('rm2_tests',updated);setTests(updated);setShowAdd(false);}} />}
    </div>
  );
}

function AddTestModal({ sectionKey, onClose, onSave }) {
  const [form, setForm] = useState({ title: '', description: '', category: '', type: 'free', questions: 40 });
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const [err, setErr] = useState('');
  function save() {
    if (!form.title.trim()) { setErr('Nomi kiritilishi shart.'); return; }
    onSave({ id: Date.now().toString(), ...form, questions: parseInt(form.questions)||40 });
  }
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal-box" onClick={e=>e.stopPropagation()}>
        <div className="modal-title">Yangi test qo'shish — {sectionKey}</div>
        <div className="field"><label>Test nomi</label><input placeholder="Masalan: IELTS Trainer 2, Test 1" value={form.title} onChange={e=>set('title',e.target.value)} /></div>
        <div className="field"><label>Kategoriya</label><input placeholder="Masalan: IELTS Trainer 2" value={form.category} onChange={e=>set('category',e.target.value)} /></div>
        <div className="field"><label>Tavsif</label><input placeholder="Qisqacha tavsif" value={form.description} onChange={e=>set('description',e.target.value)} /></div>
        <div className="field"><label>Turi</label>
          <select value={form.type} onChange={e=>set('type',e.target.value)} style={{width:'100%',padding:'0.7rem 1rem',border:'1.5px solid var(--border)',borderRadius:'10px',fontSize:'0.9rem',outline:'none'}}>
            <option value="free">Bepul</option>
            <option value="premium">Premium</option>
          </select>
        </div>
        {(sectionKey==='listening'||sectionKey==='reading') && <div className="field"><label>Savollar soni</label><input type="number" value={form.questions} onChange={e=>set('questions',e.target.value)} /></div>}
        {err&&<div className="err-box">{err}</div>}
        <div className="modal-footer">
          <button className="btn btn-ghost" onClick={onClose}>Bekor qilish</button>
          <button className="btn btn-primary" onClick={save}>Qo'shish</button>
        </div>
      </div>
    </div>
  );
}

// ── ROOT ──
export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('home');
  const [selectedTest, setSelectedTest] = useState(null);
  const [testSection, setTestSection] = useState(null);

  useEffect(() => { initStorage(); }, []);

  function login(u) { setUser(u); setPage('home'); }
  function logout() { setUser(null); setPage('home'); setSelectedTest(null); }

  function nav(p) {
    if (!user && !['home','auth'].includes(p)) { setPage('auth'); return; }
    setSelectedTest(null);
    setPage(p);
  }

  function selectTest(t, sk) { setSelectedTest(t); setTestSection(sk); setPage('taking'); }

  if (page === 'auth') return <div className="app"><AuthPage onLogin={login} /></div>;

  const SECTION_PAGES = ['listening','reading','writing','speaking'];

  return (
    <div className="app">
      <Navbar user={user} onLogout={logout} onNav={p => { if (!user && !['home'].includes(p)) { setPage('auth'); return; } nav(p); }} />
      <div className="main">
        {page==='home' && <HomePage user={user} onNav={p => { if (!user) { setPage('auth'); return; } nav(p); }} />}
        {SECTION_PAGES.includes(page) && <SectionPage sectionKey={page} user={user} onBack={()=>nav('home')} onSelectTest={selectTest} onNav={nav} />}
        {page==='fullmock' && <FullMockPage user={user} onBack={()=>nav('home')} onSelectMock={m => selectTest(m,'listening')} onNav={nav} />}
        {page==='taking' && selectedTest && <TestTakingPage test={selectedTest} sectionKey={testSection} user={user} onBack={()=>nav(testSection||'home')} />}
        {page==='admin' && user?.role==='admin' && <AdminPanel user={user} onNav={nav} />}
        {page==='profile' && user && <ProfilePage user={user} onNav={nav} />}
        {page==='premium-request' && user && <PremiumRequestPage user={user} onBack={()=>nav('home')} />}
      </div>
    </div>
  );
}
